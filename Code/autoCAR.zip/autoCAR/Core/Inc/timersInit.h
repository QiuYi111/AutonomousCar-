/*
 * timersInit.h
 *
 *  Created on: Jul 21, 2024
 *      Author: 25138
 */

#ifndef INC_TIMERSINIT_H_
#define INC_TIMERSINIT_H_

#include "tim.h"
void timersInit();



#endif /* INC_TIMERSINIT_H_ */
