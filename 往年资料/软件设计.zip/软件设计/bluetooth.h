enum COMMAND
{
   FORWARD = 1,
   BACKWARD,
   LEFT,
   RIGHT
};
