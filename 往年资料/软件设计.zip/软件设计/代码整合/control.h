/*
 * control.h
 *
 *  Created on: Aug 1, 2023
 *      Author: 21671
 */

#ifndef INC_CONTROL_H_
#define INC_CONTROL_H_

#define car_width 200

void set_car_speed(int8_t direction, int speed, int radius); //第一个参数为±1， 1表示左转，-1表示右转

#endif /* INC_CONTROL_H_ */
